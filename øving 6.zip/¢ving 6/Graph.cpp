#include "Graph.hpp"
#include "Temperatures.hpp"









void showgraphes(){
    vector<Temps>t;
    file_to_vec(t);


    Window win{Point{100,100},xmax,ymax,"Temperatures."};
   
    Axis x {Axis::x,Point{xoffset,ymax-yoffset},
    xlength,(end_month-base_month)/10,
    "Måned      Feb     Mar     Apr     May     Jun     Jul     Aug     Sep     Oct     Nov     Dec     Jan"};
    x.label.move(-100,0);
    x.set_color(Color::black);
    win.attach(x);

    Axis y{Axis::y,Point{xoffset,ymax-yoffset},ylenght,10,"0    10  20"};
    y.set_color(Color::black);
    win.attach(y);
    Scale xs{xoffset,base_month,xscale};
    Scale ys{ymax-yoffset,0,-yscale};


    Open_polyline max_temps;
    Open_polyline min_temps;
    int i = 0;
    for(auto temp : t){
       max_temps.add(Point{ i, temp.max });
        min...
        i++;
    }

}


void Data(){


    
}
