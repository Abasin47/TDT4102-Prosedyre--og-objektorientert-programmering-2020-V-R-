#pragma once
#include "std_lib_facilities.h"
#include "Graph.h"
#include "Simple_window.h"
using namespace Graph_lib;
constexpr int xmax=700;
constexpr int ymax=400;

constexpr int xoffset=100;
constexpr int yoffset=100;

constexpr int xspace=50;
constexpr int yspace=50;

constexpr int xlength=xmax-xoffset-xspace;
constexpr int ylenght=ymax-yoffset-yspace;

constexpr int base_month=0;
constexpr int end_month=12;
constexpr double xscale=double(xlength)/(end_month-base_month);
constexpr double yscale=double(ylenght)/100;


class Scale{
    int cbase;
    int vbase;
    double scale;
public:
    Scale(int b,int vb,double s):cbase{b},vbase{vb},scale{s}{}
    int operator()(int v)const{return cbase+(v-vbase)*scale;}
};

void Showgraphes();

void Data();


