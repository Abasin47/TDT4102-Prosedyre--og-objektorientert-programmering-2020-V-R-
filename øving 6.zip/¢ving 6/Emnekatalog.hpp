#pragma once
#include "std_lib_facilities.h"

class CourseCatalog{
    private:
    map<string,string>fag;
    public:
    CourseCatalog();
    friend ostream& operator<<(ostream& os, const CourseCatalog& cat);
        
    void addCourse();
    void removeCourse();
    string getCourse();
    void Lastopp(CourseCatalog a);
};

