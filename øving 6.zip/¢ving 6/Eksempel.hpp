#pragma once
void showGraph();
void showGraphScale();