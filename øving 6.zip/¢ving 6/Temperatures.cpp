#include "Temperatures.hpp"

 istream&operator>>(istream&is,Temps& dag){
     
   is>>dag.max>>dag.min;
   return is;

    
 }


void file_to_vec( vector<Temps>temps){
  ifstream temperatures;
  temperatures.open("temperatures.txt");
 
  Temps cel;
  
  while (!temperatures.eof())
  {
    temperatures>>cel;
    temps.push_back(cel);
  }
  temperatures.close();

 

}







