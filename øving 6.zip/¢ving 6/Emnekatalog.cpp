#include "Emnekatalog.hpp" 
#include "std_lib_facilities.h"


CourseCatalog::CourseCatalog

(){};
ostream& operator<<(ostream& os, const CourseCatalog& cat){
    for(const auto &f:cat.fag){
        os<<"Emnekode: "<<f.first<<" Emnenavn: "<<f.second<<endl;


    }
    return os;

}
        

void CourseCatalog::addCourse(){
    string emnekode,emnenavn;
    cout<<"Gi kode:";
    cin>>emnekode;
    cout<<endl;
    cout<<"Gi navn:";
    cin>>emnenavn;
    fag.insert({emnekode,emnenavn});
    string emnekode1,emnenavn1;
    cout<<"Gi kode:";
    cin>>emnekode1;
    cout<<endl;
    cout<<"Gi navn:";
    cin>>emnenavn1;
    fag[emnekode1]=emnenavn1;
    


}

void CourseCatalog::removeCourse(){
   string emnenavn;
   cout<<"Gi fagnavn for å slette: " <<endl;
   cin>>emnenavn;
   fag.erase(emnenavn);

}

string CourseCatalog::getCourse(){
    cout<<"Gi kode:";
    string kode ;
    cin>>kode;
    return fag[kode];
    

}

void CourseCatalog::Lastopp(CourseCatalog a){
    ofstream ofs{"Course.txt"};
    ofs<<a<<endl;
    ofs.close();
   
}


