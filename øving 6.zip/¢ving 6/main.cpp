//
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
// 
// keep_window_open() added for TDT4102, excercise 0

// This program outputs the message "Hello, World!" to the monitor

#include "std_lib_facilities.h"
#include "Emnekatalog.hpp"
#include "Temperatures.hpp"
#include "Graph.h"
#include "Simple_window.h" 

//------------------------------------------------------------------------------'



void oppgave1(){
	
	ofstream skriv{"blablabla.txt"};
	string input;
	cout<<"Input fra bruker: ";
	cin>>input;
	skriv<<input<<endl;
	cout<<"1b)"<<endl;
	ifstream hent{"Hentfil.txt"};
	string line;
	while(getline(hent,line)){
		skriv<<line<<endl;
	}
	skriv.close();
	hent.close();


}


void oppgave2(){

	map<char,int>bokstaver;
	ifstream grunnloven{"grunnloven.txt"};
	char tegn;
	int antall;
	while (grunnloven>>tegn)
	{
		if(tolower(tegn)>=97&&tolower(tegn)<=122){
			bokstaver[tolower(tegn)]++;	}
	
	}
	for (const auto&b:bokstaver){
		cout<<b.first<<" "<<b.second<<endl;}
	
	grunnloven.close();

}





int main()
{
	//oppgave1();
	cout<<"::::::::::::::::::::::::::::::::::"<<endl;
	cout<<endl;
	cout<<"oppgave 2"<<endl;
	oppgave2();
	cout<<endl;
	cout<<":::::::::::::::::::::::::::::::::::"<<endl;
	cout<<"oppgave 3"<<endl;
	CourseCatalog c;
	c.addCourse();
	cout<<c;
	c.Lastopp(c);
	cout<<":::::::::::::::::::::::::::::::::::"<<endl;
	
	cout<<"oppgave4"<<endl;
	vector<Temps>cel;

	file_to_vec(cel);
	keep_window_open();
	cout<<"::::::::::::::::::::::::::::::::::::::"<<endl;
	cout<<"oppgave 5"<<endl;


}

//------------------------------------------------------------------------------
