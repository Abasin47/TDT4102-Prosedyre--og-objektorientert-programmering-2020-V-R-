#pragma once
#include "std_lib_facilities.h"




struct Temps{
    double max;
    double min;
};
void file_to_vec( vector<Temps>temps);

