#include "Graph.h"
#include "Simple_window.h" 
#include "Eksempel.hpp"

using namespace Graph_lib;

constexpr int windowWidth = 600;    // ymax
constexpr int windowHeight = 600;   // xmax

constexpr int chartHeight = 400;    // ylength
constexpr int chartWidth = 400;     // xlength

constexpr int chartOffsetX = 100;   // xspace
constexpr int chartOffsetY = 100;   // yspace

constexpr int chartBaselineX = chartOffsetX;                // Venstre side av grafen 
constexpr int chartBaselineY = chartOffsetY + chartHeight;  // Grunnlinjen i grafen

constexpr int start_year = 1989;
constexpr int end_year = 2018;

constexpr double yMaxValue = 10;

constexpr double xscale = static_cast<double>(chartWidth)/(end_year - start_year);
constexpr double yscale = static_cast<double>(chartHeight)/(yMaxValue);

// Data sÃ¥ vi har noe Ã¥ tegne. Dette er arbeidsledigheten Ã¥r for Ã¥r fra 1989 til 2018.
map<int, double> percentSeekingWork = {
    { 1989, 1.7},
    { 1990, 1.5},
    { 1991, 1.5},
    { 1992, 2.3},
    { 1993, 1.8},
    { 1994, 1.5},
    { 1995, 1.8},
    { 1996, 2},
    { 1997, 1.7},
    { 1998, 2},
    { 1999, 2.6},
    { 2000, 3.4},
    { 2001, 3.2},
    { 2002, 2.6},
    { 2003, 2},
    { 2004, 2.1},
    { 2005, 3.2},
    { 2006, 4.9},
    { 2007, 5.2},
    { 2008, 5.5},
    { 2009, 5.9},
    { 2010, 6},
    { 2011, 5.4},
    { 2012, 4.9},
    { 2013, 4.8},
    { 2014, 4},
    { 2015, 3.2},
    { 2016, 3.2},
    { 2017, 3.4},
    { 2018, 3.5}
};

void showGraph() {
	// Lage et vindu
	Simple_window win{ {100, 100}, windowWidth, windowHeight, "An interesting graph" };

	// Lage x-aksen vÃ¥r, justere posisjonen til labelen og koble den til vinduet
	Axis x{ Axis::Orientation::x, {chartBaselineX, chartBaselineY}, chartWidth, 0, "Year" };
	x.label.move(-30, 0);				// PrÃ¸v og feil for Ã¥ finne gode verdier her
	x.set_color(Color::black);
	win.attach(x);

	// En linje som viser trenden i antall arbeidsledige
	Open_polyline seekingWork;

	for (auto& value: percentSeekingWork) {
		// Finn posisjonen i y-retning - eksempelet i boken bruker er funksjonsobjekt, se side 543
		int y = chartBaselineY - value.second * yscale;
		// Finn posisjonen i x-retning
		int x = chartBaselineX + xscale * (value.first - start_year);

		// Legg til punktet pÃ¥ grafen/linjen vÃ¥r
		seekingWork.add(Point{ x, y });
	}

	// Sett farge pÃ¥ linjen og koble den til vinduet
	seekingWork.set_color(Color::dark_blue);
	win.attach(seekingWork);

	// Vente pÃ¥ en trykker pÃ¥ knappen fÃ¸r vi gÃ¥r videre
	win.wait_for_button();
}

/**
 * 
 * 
 * Her kommer den samme koden, men vi har brukt samme skalering som i boken 
 * 
 * Eneste unntaket er at operator() tar en double fremfor int. 
 * 
 * 
 * */

// Hentet (nesten) direkte fra boken, se side 543
class Scale
{
   int cbase;
   int vbase;
   double scale;
public:
    Scale(int b, int v, int s): cbase(b), vbase(v), scale(s) { }
    int operator()(double v) const { return cbase + (v-vbase) * scale; } 
};



void showGraphScale() {
	// Lage et vindu
	Simple_window win{ {100, 100}, windowWidth, windowHeight, "An interesting graph" };

	// Lage x-aksen vÃ¥r, justere posisjonen til labelen og koble den til vinduet
	Axis x{ Axis::Orientation::x, {chartBaselineX, chartBaselineY}, chartWidth, 0, "Year" };
	x.label.move(-30, 0);				// PrÃ¸v og feil for Ã¥ finne gode verdier her
	x.set_color(Color::black);
	win.attach(x);

    // Vi lager to to funksjonsobjektene 
    Scale xs(chartBaselineX, start_year, xscale);
    Scale ys(chartBaselineY, 0, -yscale);

	// En linje som viser trenden i antall arbeidsledige
	Open_polyline seekingWork;

	for (auto& currentValue: percentSeekingWork) {
		// Finn posisjonen i y-retning - eksempelet i boken bruker er funksjonsobjekt, se side 543
        int x = xs(currentValue.first);
		int y = ys(currentValue.second);

		// Legg til punktet pÃ¥ grafen/linjen vÃ¥r
		seekingWork.add(Point{ x, y });
	}

	// Sett farge pÃ¥ linjen og koble den til vinduet
	seekingWork.set_color(Color::dark_blue);
	win.attach(seekingWork);

	// Vente pÃ¥ en trykker pÃ¥ knappen fÃ¸r vi gÃ¥r videre
	win.wait_for_button();
}

