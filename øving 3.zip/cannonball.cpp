
#include "cannonball.hpp"
#include "cmath"
#include "cstdlib"


double accIY(){
	const double y=-9.81;
	return y;
}

double velY(double time,double initVelocityY){
	double velY=initVelocityY+time*accIY();

	return velY;

}

double posX(double initPosition, double initVelocity, double time){
	
	double posX=initPosition+initVelocity*time;
	return posX;

}

double posY(double initPosition,double initVelocity,double time){
	double posY=initPosition+initVelocity*time+accIY()*0.5*time*time;
	return posY;
}

void printTime(double time){
	int tid=time;

	int hour=time/3600;
	int minutt=(time-(time/3600))/60;
	int sec =( tid-(tid/3600))%60;
	cout<<hour<<":"<<minutt<<":"<<sec;
	
}

double flyvetid(double startfart_y){
	double flyvetid=-2*startfart_y/accIY();
	return flyvetid;
	
}
double getUserInputTheta(){
    double vinkel;
    cin>>vinkel;
    return vinkel;
    
}

double getUserInputAbsVelocity(){
    double fart;
    cin>>fart;
    return fart;
    
}

double degToRad(double deg){
    double rad=3.141592653*(deg/180.0);
    

    return rad;

}

double getVelocityX(double theta, double absVelocity){
    double vink=3.141592653*(theta/180.0);
    
  
    double FartX=absVelocity*cos(double(vink));
    return FartX;

}
double getVelocityY(double theta, double absVelocity){
    double FartY=absVelocity*sin(theta);
    return FartY;
}
vector<double> getVelocityVector(double theta,double absVelocity){
    
    double a=getVelocityX(theta,absVelocity);
    double b=getVelocityY(theta,absVelocity);
    vector<double> fart={a,b};
    return fart;
        
}
double getDistanceTraveled(double velocityX,double velocityY){
    double tid=flyvetid(velocityY);
    double fart=sqrt(pow(velocityY,2)+pow(velocityX,2));
    double distance=posX(0,fart,tid);
    return distance;

}

double targetPractice(double distanceToTarget,double velocityX,
double velocityY){
    double regnet=getDistanceTraveled(velocityX,velocityY);
    double avvik=distanceToTarget-regnet;
    return abs(avvik);

}
