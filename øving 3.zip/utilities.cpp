
#include "utilities.hpp"
#include "cstdlib"
#include "std_lib_facilities.h"
#include "cannonball.hpp"


int tilfeldig(){
    srand(static_cast<unsigned>(time(nullptr)));
    return rand();    
}
int randomWithLimits(int min, int max){
    srand(static_cast<unsigned>(time(nullptr)));
    return rand()%((max+1)-min); 
}

void playTargetPractice(){
    int mål=randomWithLimits(100,1000);

    int forsøk=1;
    while(forsøk!=10){
        cout<<"gi vinkel"<<endl;
        double vink=getUserInputTheta();
        cout<<"gi startfart"<<endl;
        double startfart=getUserInputAbsVelocity();
        double fartX=getVelocityX(vink,startfart);
        double fartY=getVelocityY(vink,startfart);
        double distanse=-getDistanceTraveled(fartX,fartY);
        double avvik=targetPractice(mål,fartX,fartY);
        double tid=flyvetid(startfart);
      
        if (avvik<=5.0){
            cout<<"Du var "<<avvik<<"meter unna,"<<"gratulerer."<<endl;
            forsøk+=1;
        }
        if(mål>distanse){
        cout<<avvik<<" meter unna."<<endl;
        cout<<"mer kraft"<<endl;
        printTime(tid);cout<<" "<<"tiden kula brukte"<<endl;
        forsøk+=1;
        }
         if (mål<distanse){
            cout<<avvik<<" meter unna."<<endl;
            cout<<"mindre kraft"<<endl;
            printTime(tid);cout<<" "<<"tiden kula brukte"<<endl;
            forsøk+=1;
        }
    
    
    } 
    cout<<"Du tapte.Ha en fin dag videre."<<endl;

}

