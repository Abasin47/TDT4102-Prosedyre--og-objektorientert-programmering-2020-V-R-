
#pragma once
#include "std_lib_facilities.h"
#include "cstdlib"

double accIY();
double velY(double time,double initVelocitY);
double posX(double initPostion,double initVelocity,double time);
double posY(double initPosition,double initVelocity,double time);
void printTime(double time);
double flyvetid(double startfart_y);

double getUserInputTheta();

double getUserInputAbsVelocity();

double degToRad(double deg);

double getVelocityX(double theta, double absVelocity);

double getVelocityY(double theta, double absVelocity);

vector<double> getVelocityVector(double theta,double absVelocity);

double getDistanceTraveled(double velocityX,double velocityY);

double targetPractice(double distanceToTarget,
double velocityX,
double velocityY);