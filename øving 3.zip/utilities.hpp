#pragma once


int tilfeldig();
int randomWithLimits(int min,int max);
void playTargetPractice();
