#include "std_lib_facilities.h"
#include "cannonball.hpp"
#include "cstdlib"
#include "iostream"
#include "utilities.hpp"
#include "viz.h"


void testDeviation(double compareOperand,double toOperand,double maxError,string name);



int main(){
    cannonBallViz(500.0,1000,70.5,30.0,5);
    


  


    playTargetPractice();
   
   
   
  
    for(int i=1;i<5;++i){
    
    cout<<randomWithLimits(1,9)<<endl;
   
    }


    
    cout<<accIY()<<endl;
    cout<<velY(2.5,25.0)<<endl;
    cout<<posY(0,31,2.5)<<endl;
    cout<<posX(0,31,2.5)<<endl;
    printTime(125);cout<<endl;
    cout<<flyvetid(2.7)<<endl;
    testDeviation(posX(0.0,50.0,5.0),252.0,0.01,"posX(0.0,50.0,5.0)");
    cout<<"Oppgave 4a"<<endl;
    cout<<getUserInputTheta()<<endl;
    cout<<getUserInputAbsVelocity()<<endl;
    cout<<degToRad(90.0)<<endl;
    cout<<getVelocityX(90.0,5.0)<<endl;
    cout<<getVelocityY(90.0,5.0)<<endl;
    cout<<"Vektor:"<<endl;
    
    vector<double>fart=getVelocityVector(90.0,5.0);
    for(int i=0;i<2;++i){
        cout<<fart[i]<<setw(2)<<endl;
    
    }
    cout<<"oppgave 4b"<<endl;
    cout<<getDistanceTraveled(4,4)<<endl;
    cout<<"oppgave 4c"<<endl;
    cout<<targetPractice(25.0,22.9,22.0)<<endl;
    keep_window_open();



}
void testDeviation(double compareOperand,double toOperand,double maxError,string name){
    double error=compareOperand-toOperand;
    if(abs(error)> maxError){
        cout<<"For stor feil i "<<name<<endl;

    }
    else{
        cout<<"Nice."<<endl;
    }


}




