#include "Emoji.h"



Face::Face(Point s,int r):
    sirkel{s,r}{sirkel.set_fill_color(Color::yellow);}
void Face::attach_to(Graph_lib::Window&win){
    win.attach(sirkel);
}


EmptyFace::EmptyFace(Point s,int r) :Face{s,r},
eye1({s.x+(r/2),s.y-(r/7)},(r/5)),
eye2({s.x-(r/2),s.y-(r/7)},(r/5)){
    eye1.set_fill_color(Color::white);
    eye2.set_fill_color(Color::white);

}

  

void EmptyFace::attach_to(Graph_lib::Window&win){
    Face::attach_to(win);
    win.attach(eye1);
    win.attach(eye2);
    
}

Smily::Smily(Point s,int r ):EmptyFace{s,r},
munn({s.x,s.y+(r/7)},r,r,180,360)
{};

void Smily::attach_to(Graph_lib::Window&win){
    Face::attach_to(win);
    EmptyFace::attach_to(win);
    win.attach(munn);
}

Clown::Clown(Point s,int r):EmptyFace{s,r},
ball1({s.x+(r/2),s.y-(r/7)},(r/9)),
ball2({s.x-(r/2),s.y-(r/7)},(r/9)),
munn({s.x,s.y+(r/4)},r,r/10,0,180),
nese(s,r/8){
    ball1.set_fill_color(Color::black);
    ball2.set_fill_color(Color::black);
    nese.set_fill_color(Color::red);
}
void Clown::attach_to(Graph_lib::Window&win){
    Face::attach_to(win);
    EmptyFace::attach_to(win);
    win.attach(ball1);
    win.attach(ball2);
    win.attach(munn);
    win.attach(nese);
}


Coco::Coco(Point s, int r):EmptyFace{s,r},

nese({s.x,s.y},10,30),
brille1({s.x+(r/2),s.y-(r/7)},10,50),
brille2({s.x-(r/2),s.y-(r/7)},10,50),
munn({s.x,s.y+r-(r/4)},r/6,r/5,0,360),
hatt({s.x+30,s.y-30-r},40,50)
{
    brille1.set_fill_color(Color::blue);
    brille2.set_fill_color(Color::blue);
    nese.set_fill_color(Color::dark_yellow);
    hatt.set_fill_color(Color::dark_red);
}

void Coco::attach_to(Graph_lib::Window&win){
    Face::attach_to(win);
    EmptyFace::attach_to(win);
    win.attach(nese);
    win.attach(munn);
    win.attach(brille1);
    win.attach(brille2);
    win.attach(hatt);
}

Dead::Dead(Point s,int r):EmptyFace{s,r},
mu({s.x,s.y+30},100,100,180,360),
left({s.x+(r/2),s.y-(r/7)},10,20),
right({s.x-(r/2),s.y-(r/7)},10,20),
tunge({s.x,s.y-20-(r/2)},15,10),
hatt({s.x-50,s.y-r-40},100,50)

{
    mu.set_fill_color(Color::dark_green);
    right.set_fill_color(Color::dark_blue);
    left.set_fill_color(Color::dark_blue);
    tunge.set_fill_color(Color::red); 
    hatt.set_fill_color(Color::magenta);
    
}

void Dead::attach_to(Graph_lib::Window&win){
    Face::attach_to(win);
    EmptyFace::attach_to(win);
    win.attach(mu);
    win.attach(left);
    win.attach(right);
    win.attach(tunge);
    win.attach(hatt);

}








 






