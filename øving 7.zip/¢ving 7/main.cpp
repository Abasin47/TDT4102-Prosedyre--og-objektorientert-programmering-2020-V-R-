//
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
// 
// keep_window_open() added for TDT4102, excercise 0

// This program outputs the message "Hello, World!" to the monitor

#include "std_lib_facilities.h"
#include "Animal.hpp"
#include "Graph.h"
//------------------------------------------------------------------------------'

// C++ programs start by executing the function main
#include "Simple_window.h"
#include "Emoji.h"

// Size of window and emoji radius
constexpr int xmax = 1000;
constexpr int ymax = 600;
constexpr int emojiRadius = 50;

void testAnimal(){
	Cat pus("Pus",12);
	Dog Bjørnar("Bjørnar",3);
	Cat Tom("Tom",44);
	Graph_lib::Vector_ref<Animal> dyr; // Hva gjør ref:vector?
	dyr.push_back(pus);
	dyr.push_back(Tom);
	dyr.push_back(Bjørnar);
	for(int i=0;i<dyr.size();++i){
		cout<<dyr[i].toString()<<endl;
	}


}

void safeEmoji(Vector_ref<Emoji>&emojies,Graph_lib::Window&win){

}



int main()
{
	testAnimal();
	Cat c("Bob",56);
	cout<<c.toString();

	using namespace Graph_lib;

	const Point tl{100, 100};
	const string win_label{"Emoji factory"};
	Simple_window win{tl, xmax, ymax, win_label};

	/* TODO:
	 *  - initialize emojis
	 *  - connect emojis to window
	 **/
	Vector_ref<Emoji>jepp;
	
	Smily s({200,200},100);
	
	jepp.push_back(s);
	Clown g({600,200},100);
	jepp.push_back(g);
	Coco co({200,500},100);
	jepp.push_back(co);
	Dead de({600,500},100);
	de.attach_to(win);
	
	for(int i=0;i<jepp.size();++i){
		jepp[i].attach_to(win);
	}
	

	win.wait_for_button();

	keep_window_open();
}

//------------------------------------------------------------------------------
