#include "Animal.hpp"

Animal::Animal(string navn, int alder):name{navn},age{alder}{};
   



string Animal::toString(){
    string nameS=to_string(name); ///stqatic cast fungerte ikke på age
    string ageS=to_string(age);
    string Animal="Animal: ";
    return (Animal+nameS+" "+ageS);
}


Cat::Cat(string navn,int alder):Animal{navn,alder}{}


string Cat::toString(){
    string nameS=to_string(name); 
    string ageS=to_string(age);
    string Animal="Cat: ";
    return (Animal+nameS+" "+ageS);
    
}

Dog::Dog(string navn,int alder):Animal{navn,alder}{};

string Dog::toString(){
    string nameS=to_string(name); 
    string ageS=to_string(age);
    string Animal="Dog: ";

    return (Animal+nameS+" "+ageS);
    
}