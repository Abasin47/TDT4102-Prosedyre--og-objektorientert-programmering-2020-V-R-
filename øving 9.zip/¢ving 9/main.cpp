
#include "iostream"
#include "process.h"
#include "Matrix.hpp"
#include "Dummy.hpp"
using namespace std;
void fillInFibonacciNumbers(int result[],int lenght){
	result[0]=0;
	result[1]=1;

	for(int i=2;i<lenght;++i){
		result[i]=result[i-2]+result[i-1];
	}


}

void printArray(int arr[],int lenght){

	for(int i=0;i<lenght;++i){
		cout<<arr[i]<<endl;
	}

}

void createFibonacci(){
	int lengde;
	cout<<"Antall tall som skal genereres: ";
	cin>>lengde;
	cout<<endl;
	int *tall=new int[lengde]{};
	fillInFibonacciNumbers(tall,lengde);
	printArray(tall,lengde);





	delete [] tall;
	tall=nullptr;

}





int main()
{
	cout<<"Oppgave 1:"<<endl;
	createFibonacci();
	cout<<"Oppgave 2"<<endl;

	Matrix a;
	cout << a;
	cout<<endl;
	

	cout<<"oppgave 3"<<endl;
	Dummy d;
	d.dummytest();
	system("pause");

	
}


