#include "iostream"
using namespace std;


class Dummy{
    public:
    int *num;
    Dummy(){
        num=new int{0};
    }
    ~Dummy(){
        delete num;
    }
    void dummytest();
    int get()const{return *num;}
    Dummy(const Dummy &noe);
    Dummy& operator=( Dummy rhs);
};