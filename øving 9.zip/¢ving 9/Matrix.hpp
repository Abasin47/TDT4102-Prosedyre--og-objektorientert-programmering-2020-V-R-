#include "iostream"
using namespace std;

class Matrix{ 
    private:
    double **MxN;
    int row;
    int column;
    
    public:
    Matrix():MxN{nullptr}{};
    Matrix(int nRows,int nColumns);
    explicit Matrix(int nRows);
    ~Matrix();
    double get(int row,int col)const;
    void set(int row,int col,double value);

    friend ostream & operator<<(ostream & os,const Matrix & Matt);
    int getRows() const;
    int getColumns() const;
    bool isvalid() const;
    Matrix(const Matrix & kopi);
    Matrix& operator=(Matrix & rhs);
    
};





