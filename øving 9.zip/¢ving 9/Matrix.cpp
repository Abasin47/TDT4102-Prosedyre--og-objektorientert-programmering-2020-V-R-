#include "Matrix.hpp"


Matrix::Matrix(int nRows,int nColumns):row{nRows},column{nColumns} 
{
    MxN=new double *[row];
    for(int i=0;i<row;++i){
        MxN[i]=new double[column];
        for(int j=0;j<column;++j){
            MxN[i][j]=0;
        }
    }

}

 Matrix::Matrix(int nRows):Matrix{nRows,nRows}{
      for(int i=0;i<nRows;++i){
          MxN[i][i]=1;
      }
  }


Matrix::~Matrix(){
    for(int i=0;i<row;++i){
        delete[] MxN[i];
        MxN[i]=nullptr;
        delete MxN;
        MxN=nullptr;
    }
}

double Matrix::get(int row,int col) const{
    
    return MxN[row][col];

}
void Matrix::set(int row,int column,double value){
    MxN[row][column]=value;
    

}

int Matrix::getRows() const{
    return row;

}

int Matrix::getColumns() const{
    return column;  
}

bool Matrix::isvalid() const{
    if(MxN==nullptr){
        return false;
    }
    return true;
}

ostream & operator<<(ostream & os,const Matrix & matt){
    if(matt.isvalid()){
        for(unsigned int i=0;i< matt.row;++i){
            os<<endl;
            for(unsigned int j=0;j<matt.column;++j){
                os<<matt.get(i,j)<<" ";


            }
        }

        return os;

    }
    os<<"ugyldig  matrise"<<endl;
    return os;
}


Matrix::Matrix(const Matrix & kopi):Matrix{kopi.row,kopi.column}
{
    for(int i=0;i<row;++i){
        for(int j=0;j<column;++j){
            MxN[i][j]=kopi.get(i,j);
        }
    }
    

}



Matrix& Matrix::operator=(Matrix& rhs){
    swap(MxN,rhs.MxN);
    swap(row,rhs.row);
    swap(column,rhs.column);
    return *this;

}











