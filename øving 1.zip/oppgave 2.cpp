
#include "std_lib_facilities.h"


int maxOfTwo(int A,int B){
	if (A>B){
		cout<<"A is greater than B"<<'\n';
		return A;
	} else{
		cout<<"B is greater than or equal to A"<<'\n';
		return B;
	}
}


int fibonnacci(int n){
    int a= 0;
    int b=1;
    cout<<"Fibonacci numbers"<<'\n';
    for (int x=1;x<n+1;++x){
        cout<<(x)<<":"<<(b)<<'\n';
        int temp=b;
        b+=a;
        a=temp;
    }
    cout<<"-----"<<'\n';

    return b;


}

int squareNumbersum(int n ){
	int totalsum=0;
	for (int i=0; i<n;++i){
		totalsum+=(i*i);
		cout<<(i*i)<<'\n';
	}
	cout<<totalsum<<'\n';
	return totalsum;
	
}


void triangleNumberesBelow(int n){
	int acc=1;
	int num=2;
	string sep=" ";
	cout<<"Triangle numbers below"<<(n)<<":"<<(sep)<<'\n';
	while (acc<n){
		cout<<(acc)<<'\n';
		acc+=num;
		num+=1;
		

	}
	cout<<" "<<'\n';
	
}

bool isPrime(int n){
	for(int j=2;j<n;++j){
		if(n%j==0){
			return false;
		}


	}
	return true ;

}
void naivePrimeNumberSearch(int n ){
	for (int number=2;number<n;++number){
		if(isPrime(number)){
			cout<<(number)<<" is a prime"<<'\n';
		}
	}

}
int findgreatestdivisor(int n){
	for(int divisor=n-1; divisor<n; divisor=divisor-1 ){
		if(n%divisor==0){
			return divisor;
		}
	}
}



int main(){
	cout << "Oppgave a)"<<'\n';
	cout << maxOfTwo(5, 6) << '\n';
	cout<<"oppgavec)"<<'\n';
	cout<<fibonnacci(3)<<'\n';
	cout<<"oppgaev d)"<<'\n';
	cout<<squareNumbersum(4)<<'\n';
	cout<<"Oppgave e)"<<'\n';
	triangleNumberesBelow(9);
	cout<<"oppgave f"<<'\n';
	cout<<isPrime(3)<<'\n';
	cout <<"oppgave g"<<'\n';
	naivePrimeNumberSearch(3);
	cout<<"oppgave h"<<'\n';
	cout << findgreatestdivisor(8)<<'\n'; 
	keep_window_open();
}






