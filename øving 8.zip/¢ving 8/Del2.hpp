#include"Graph.h"
#include "std_lib_facilities.h"
#include "Window.h"
#include "GUI.h"
#include "Person.hpp"

using namespace Graph_lib;




class MeetingWindow:public Window{
    private:
    static constexpr int pad=400;
    static constexpr int btnW=50;
    static constexpr int btnH=30;
    static constexpr int fieldW=100;
    static constexpr int fieldH=15;
    static constexpr int fieldPad=60;
    Button quitBtn;
    In_box personName;
    In_box personEmail;
    Vector_ref<Person>people;
    Button personNewBtn;




    public:
    MeetingWindow(Point xy,int w,int h,const string& title);
    void addPerson();
    static void cb_quit(Address,Address pw){
        reference_to<MeetingWindow>(pw).hide();
    };
    static void cb_new_person(Address,Address pw){
        reference_to<MeetingWindow>(pw).addPerson();
    }
    void printmedlem();
  

};