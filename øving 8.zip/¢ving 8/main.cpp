

#include "std_lib_facilities.h"
#include "Car.hpp"
#include "Person.hpp"
#include "Meetings.hpp"
#include "Del2.hpp"

using namespace Graph_lib;
int main()

{
	Car c(5);
	c.hasFreeSeats();
	Car *bil=&c;
	Person p("Knut","kNuterkul22.BO",bil);
	cout<<p.getPerson()<<endl;
	cout<<p.hasAvialableSeats()<<endl;
	cout<<p<<endl;


	Campus camp(Campus::Trondheim);
	Person gunnar("Gunnar","Gunnarerfett@mail.no",bil);
	const Person *leder=&gunnar;

	Meeting meet(5,15,16,camp,"Matte",leder);

	cout<<meet.getDay()<<endl;
	cout<<meet.getEndTime()<<endl;
	meet.addParticipant(leder);
	cout<<meet;

	constexpr int width=500;
	constexpr int height=500;
	const Point xy{(x_max()-width)/2,(y_max()-height)/2};
	MeetingWindow test{xy,width,height,"MeetingWindow"};
	
	gui_main();
	test.printmedlem();
	keep_window_open();
	

	

	


	
}




//------------------------------------------------------------------------------
