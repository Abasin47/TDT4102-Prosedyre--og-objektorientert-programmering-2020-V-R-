#include "std_lib_facilities.h"
#include "Person.hpp"
#include "Car.hpp"
enum class Campus{ Trondheim, Ålesund,Gjøvik};
ostream& operator<<(ostream&out,const Campus& ntnu);

class Meeting{
    private:
    int day;
    int startTime;
    int endTime;
    Campus location;
    string subject;
    const Person* leader;
    set<const Person*> participants;
    static set<const Meeting*> meetings;

    public:
    Meeting(int dag,int starttid,int slutttid,Campus lokasjon,string fag,const Person*leder);
    vector<const Person*> findPotentialCoDriving();
    int getDay(){
        return day;
    };
    int getStartTime(){
        return startTime;
    };
    int getEndTime(){
        return endTime;
    };
    Campus getLocation(){
        return location;

    };
    string getSubject(){
        return subject;
    };
    Person getPerson(){
        return *leader;


    };
    void addParticipant(const Person*p);
    vector<string> getParticipants();
    ~Meeting(){cout<<"Slett"<<endl;};

};

ostream& operator<<(ostream& os,Meeting& meet);

