#include "Meetings.hpp"








Meeting::Meeting(int dag,int starttid,int slutttid,Campus lokasjon,string fag,const Person*leder) : day{dag},startTime{starttid},endTime{slutttid},location{lokasjon},subject{fag},leader{leder}{
addParticipant(leader);
meetings.insert(this);

};


set<const Meeting*>Meeting::meetings;



void Meeting::addParticipant(const Person*p){
    participants.insert(p);
}

vector<string> Meeting::getParticipants(){
    vector<string>deltakere;
    for(auto i:participants){
        deltakere.push_back(i->getPerson());
        
    }
    return deltakere;

}
ostream& operator<<(ostream&out,const Campus& ntnu){
    switch(ntnu){
        case Campus::Trondheim: out<<"Trondheim";break;
        case Campus::Gjøvik: out<<"Gjøvik";break;
        case Campus::Ålesund:out<<"Ålesund";break;


    }
    return out;
}

ostream& operator<<(ostream&os,Meeting& meet){
    vector<string>deltakere=meet.getParticipants();
   
    os<<"Fag:"<<meet.getSubject()<<" , "<<"start_tid:"<<meet.getStartTime()<<" ,  "<<"slutttid:"<<meet.getEndTime()<<",  "<<"Lokasjon:"<<meet.getLocation()<<" , Deltakere:";
    
    for(int i=0;i<deltakere.size();++i){
        os<<deltakere[i]<<endl;
    }
    return os;
}

vector<const Person*> Meeting::findPotentialCoDriving(){
    vector<const Person*> muligePartner;
    for(auto i:meetings){
        if(location==i->location && 1>=abs(startTime-i->startTime) && 1>=(endTime-i->endTime) && day==i->day && leader->hasAvialableSeats()){
            muligePartner.push_back(this->leader);}



    }
    return muligePartner;

}

