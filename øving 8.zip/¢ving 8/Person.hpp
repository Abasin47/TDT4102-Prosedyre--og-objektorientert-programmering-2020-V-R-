#pragma once
#include "std_lib_facilities.h"
#include "Car.hpp"
class Person{
    private:
    string name;
    string email;
    Car *PersonCar;
    public:
    Person(string navn,string epost,Car*car=nullptr);
    void setMail();
    string getPerson()const;
    string getMail()const;
    string get()const;
    bool hasAvialableSeats()const;
    friend ostream& operator<<(ostream& ut, Person& p);
};




