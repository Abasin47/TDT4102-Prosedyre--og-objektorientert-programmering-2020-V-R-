#include "Car.hpp"

Car::Car(int seter){
    freeSeats=seter;

}

bool Car::hasFreeSeats() const{
    if(freeSeats>0){
        return true;
    }
    return false;
}

void Car::reserveFreeSeats(){
    freeSeats=freeSeats-1;
}