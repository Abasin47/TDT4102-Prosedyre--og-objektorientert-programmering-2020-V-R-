#include "Del2.hpp"
#include "Graph.h"

MeetingWindow::MeetingWindow(Point xy,int w,int h,const string& title):
Window{xy,w,h,title},
quitBtn{Point{pad,pad},btnW,btnH,"Avslutt",cb_quit},
personName{Point{fieldPad,pad-200},fieldW,fieldH,"Navn"},
personEmail{Point{fieldPad,pad-100},fieldW,fieldH,"Email"},
personNewBtn{Point{pad,pad-60},btnW+60,btnH,"Legg til person",cb_new_person}
{
    attach(quitBtn);
    attach(personName);
    attach(personEmail);
    attach(personNewBtn);

}


void MeetingWindow::addPerson(){
    string individ=personName.get_string();
    string individEmail=personEmail.get_string();
    people.push_back(new Person{individ,individEmail});
    personEmail.clear_value();
    personName.clear_value();
}
void MeetingWindow::printmedlem(){
    for(int i=0;i<people.size();++i){
        cout<<people[i]<<endl;
    }
}