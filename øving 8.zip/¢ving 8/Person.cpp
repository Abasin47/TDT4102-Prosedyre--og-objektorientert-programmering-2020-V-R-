#include "Person.hpp"
#include "Car.hpp"



Person::Person(string navn,string epost,Car*car){
    name=navn;
    email=epost;
    PersonCar=car;
    
    
    

}

void Person::setMail(){
    string mail;
    cout<<"gi mail"<<endl;
    cin>>mail;
    email=mail;

}


string Person::getPerson()const{
    return name;
}
string Person::getMail()const{
    return email;
}


bool Person::hasAvialableSeats()const{
    
    if(PersonCar->hasFreeSeats()){
        return true;
    }
    return false;
}

ostream& operator<<(ostream& ut,const Person&p){ // Hva skjer når jeg har const. Kan ikke bruke p.get().
    ut<<p.getPerson()<<" : "<<p.getMail()<<endl;
    return ut;

}


