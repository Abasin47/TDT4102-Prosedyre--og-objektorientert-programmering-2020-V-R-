

#include "std_lib_facilities.h"
#include<cmath>

int inputAndPrintInteger(){
	int a;
	cout<<"Skriv inn et tall: ";
	cin>>a;
	cout<<" Du skrev inn: ";
	return a;

}

int inputInteger(){
	int i; 
	cout<<"Skriv inn et tall: ";
	cin>>i;
	return i;


}

void inputIntegerAndprintSum(){
	int j=inputInteger();
	int k = inputInteger();
	int m = j+k;
	cout<<"Summen av tallene er "<<m<<"\n";
}


//d: inputinteger har ikke print det du skrev. 

bool isOdd( int a ){
	
	if (a%2==0){
		return false;
	}
	else { 
		
		return true;
	}
}

 void  printHumanReadableTime(int b){
	 int timer=b/3600;
	 int minutt=(b-(timer*3600))/60;
	 int sekunder=(b-(timer*3600))%60;


	cout<<timer<<":"<<minutt<<":"<<sekunder<<"\n";	
	

	


}

int summen(int a ){
	int s=0;
	for (int i=0 ;i<a+1;++i){
		cin>>i;
		s=s+i;
	}
	return s;

}

int summwhile(){
	int f;
	int s=0;

	cin>>f;
	while(f!=0){
		s=s+f;
		cin>>f;
		}
	
	return s;
}


float inpoutdouble(){
	float k; 
	cin>>k;
	return k;

	

}

void conv(){
	float kurs=9.75;
	float kr=inpoutdouble();
	float Eu=kr/kurs;
	if (Eu<0){
		
		conv();	
	}
	else{
	cout<<fixed<<setprecision(2)<<Eu;
	}
}


void gangetabell(int bredde,int høyde){
	
	for(int i=1;i<høyde+1;++i){
		cout<<endl;
		for(int k=1;k<bredde+1;++k){
			int m=k*i;
			cout<<m<<setw(5);
		}
		cout<<left;	
	}
	
	

}



double discrimiant(double a,double b,double c ){
	
	double svar=b*b-4*a*c;

	return svar;


}

void printrealroots(double a, double b , double c){
	
	double root=discrimiant(a,b,c);
	if (root<0){
		cout<<"ingen mulige løsninger"<<endl;
	

	}
	else{

	double x_1=(-b+sqrt(root))/2*a;
	double x_2=(-b-sqrt(root))/2*a;
	cout<<x_1<<endl;
	cout<<x_2<<endl;
	}
}

void solveQuadraticequation(){
	double a,b,c;
	cin>>a;cin>>b;
	cin>>c;
	printrealroots(a,b,c);
}



void calculate(int beløp,int rente,int år){
	int rest=beløp;
	vector<int>innbetal(år);

	for (int i=0;i<år;++i){
		innbetal[i]=(beløp/år)+(rente/100.0)*rest;
		rest-=beløp/år;
		cout<<i+1<<setw(8)<<innbetal[i]<<endl;
		


}
}

void annuity(int beløp ,int rente ,int år){
	vector<int>innbetal(år);
	for(int i=0;i<år;++i){
		innbetal[i]=beløp*((rente/100.0))/(1-pow((1+(rente/100.0)),(-år)));
		cout<<i+1<<setw(9)<<innbetal[i]<<endl;


	}
}

void sammenlign(int beløp,int rente, int år){
	vector<int> innbetal(år);
	vector<int> innbetal_1(år);
	int rest=beløp;
	int sumA=0;
	int sumS=0;
	cout<<"År"<<"::::"<<"Annuitet"<<"::::"<<"Serie"<<"::::"<<"Differanse"<<endl;
	for(int i=0;i<år;++i){
	innbetal[i]=beløp*((rente/100.0))/(1-pow((1+(rente/100.0)),(-år)));
	innbetal_1[i]=(beløp/år)+(rente/100.0)*rest;
	sumA=sumA+innbetal[i];
	sumS=sumS+innbetal_1[i];
	rest-=beløp/år;
	cout<<i+1<<setw(10)<<innbetal[i]<<setw(10)<<innbetal_1[i]<<setw(10)<<innbetal[i]-innbetal_1[i]<<endl;
	
	}
	cout<<"-------------"<<endl;
	cout<<"total"<<"::::"<<sumA<<"::::"<<sumS<<"::::"<<sumA-sumS<<endl;

}





int main() {
	
	int valg;
	cout<<"Velg funksjon:"<<"\n";
	cout<<"0) Avslutt"<<"\n";
	cout<<"1) Summer to tall"<<"\n";
	cout<<"2) summer flere tall"<<"\n";
	cout<<"3) Konverter NOK til EURO"<<"\n";
	cout<<"4) Gangetabell"<<"\n";
	cout<<"5) andragradslikning."<<endl;
	cout<<"6) for loan"<<endl;
	cout<<"Angi valg(0-6)";
	cin>>valg;
	switch (valg){ 
	case 0:
		break;
	case 1:
		inputIntegerAndprintSum();
		main();
		break;
	case 2:
		int a;
		cout<<"Hvor mang tall vil du summere ? ";
		cin>>a;
		cout<<summen(a)<<"\n";
		main();
		break;
	case 3:
		conv();
		cout<<"\n";
		main();
		break;
	
	case 4:
		int c,b;
		cout<<"Angi høyde og bredde"<<endl;
		cin>>c;
		cin>>b;
		gangetabell(c,b);
		main();
		break;
	case 5:
		solveQuadraticequation();
		main();
		break;

	case 6:
		int beløp,rente,år;
		cout<<"Skriv inn beløp, rente og år.";
		cin>>beløp;
		cin>>rente;
		cin>>år;
		sammenlign(beløp,rente,år);



	}
	
	
	//inputAndPrintInteger();
	//int number=inputInteger();
	//cout<<" Du skrev inn: " <<number<<'\n';
	//inputIntegerAndprintSum(); 
	//isodd(7);
	//printHumanReadableTime(1);


	//2
	//cout<<summen(3)<<"\n";
	//cout<<summwhile()<<"\n";
	// først er best med for og andre er best med while.På grunn antall ganger i første og en sann eller usann tilstand i andre.
	
	//float number = inpoutdouble();
	//cout<<" Du skrev inn: " <<number<<'\n'
	//conv()

	keep_window_open();
}




	



