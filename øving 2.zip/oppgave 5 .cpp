#include "Simple_window.h"
#include "Graph.h" 


void pytagoras(){
	using namespace Graph_lib;
	Simple_window win{Point{100,100},1500,1500,"Pythagoras"};
	Polygon righttrekant;
	righttrekant.add(Point{500,500});
	righttrekant.add(Point{300,500});
	righttrekant.add(Point{300,400});
	righttrekant.set_fill_color(Color::cyan);
	win.attach(righttrekant);
	Polygon akvadrat;
	akvadrat.add(Point{300,500}); 
	akvadrat.add(Point{500,500});
	akvadrat.add(Point{500,700});
	akvadrat.add(Point{300,700});
	akvadrat.set_fill_color(Color::dark_blue);
	win.attach(akvadrat);
	Polygon bkvadrat;
	bkvadrat.add(Point{300,400});
	bkvadrat.add(Point{300,500});
	bkvadrat.add(Point{200,500});
	bkvadrat.add(Point{200,400});
	bkvadrat.set_fill_color(Color::red);
	win.attach(bkvadrat);
	Polygon ckvadrat;
	ckvadrat.add(Point{500,500});
	ckvadrat.add(Point{300,400});
	ckvadrat.add(Point{400,200});
	ckvadrat.add(Point{600,300});
	ckvadrat.set_fill_color(Color::dark_yellow);
	win.attach(ckvadrat);
	win.wait_for_button();
}




void calculate(int beløp,int rente,int år){
	int rest=beløp;
	vector<int>innbetal(år);

	for (int i=0;i<år;++i){
		innbetal[i]=(beløp/år)+(rente/100.0)*rest;
		rest-=beløp/år;
		cout<<i+1<<setw(8)<<innbetal[i]<<endl;
		


}
}

void annuity(int beløp ,int rente ,int år){
	vector<int>innbetal(år);
	for(int i=0;i<år;++i){
		innbetal[i]=beløp*((rente/100.0))/(1-pow((1+(rente/100.0)),(-år)));
		cout<<i+1<<setw(9)<<innbetal[i]<<endl;

	}


	






}


void sammenlign(int beløp,int rente , int år){



}

int main(){
	//pytagoras();
	 calculate(10000,5,10);
	 annuity(10000,5,10);
	
	keep_window_open();

}






