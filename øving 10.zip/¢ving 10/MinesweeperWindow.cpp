#include "MinesweeperWindow.h"

MinesweeperWindow::MinesweeperWindow(Point xy, int width, int height, int mines, const string& title) :
	Graph_lib::Window{xy, width * cellSize, height*cellSize, title}, width{width}, height{height}, mines{mines},antallRuter{(height*width)-mines}
	//Initialiser medlemsvariabler, bruker ogsaa konstruktoren til Windowsklassen
	
	// Legg til alle tiles paa vinduet
	,QuitBtn{Point{100, 40},40,40,"Quit",cb_quit}, 

	over{200,200,"Game 0ver"},GAMEOVER{Point{20,20},"G A ME O V E R !"},
	won{200,200,"You Won"},VIC{Point{20,20},"V I C T O R Y"}
	
	{

	GAMEOVER.set_fill_color(Color::dark_red);
	VIC.set_fill_color(Color::green);
	
	over.attach(GAMEOVER);
	over.attach(QuitBtn);
	over.hide();
	
	won.attach(VIC);
	won.attach(QuitBtn);
	won.hide();


	for (int i = 0; i < height; ++i) {
		for (int j = 0; j < width; ++j) {
			int y = i* cellSize,
				x = j * cellSize;
			tiles.push_back(new Tile{ Point{x, y}, cellSize, cb_click });
			attach(tiles.back());



		}
	}



	//Legg til miner paa tilfeldige posisjoner
	//Lager vektoren for å ikke få samme posjson.

	for(int i=0;i<mines;++i){
		int posisjon=rand()%(1+tiles.size());
		if(tiles[posisjon].getMine()==false){
			tiles[posisjon].setMine();
		}
	
		
		
	}

	// Fjern window reskalering
	resizable(nullptr);
	size_range(x_max(), y_max(), x_max(), y_max());



}

int MinesweeperWindow::countMines(vector<Point> points) const {
	int numMine=0;
	for(int i=0;i<points.size();++i){
		if(at(points[i]).getMine()){
			numMine+=1;
		}
		
	}

	return numMine;


};
vector<Point> MinesweeperWindow::adjacentPoints(Point xy) const {
	vector<Point> points;
	for (int di = -1; di <= 1; ++di) {
		for (int dj = -1; dj <= 1; ++dj) {
			if (di == 0 && dj == 0) {
				continue;
			}

			Point neighbour{ xy.x + di * cellSize,xy.y + dj * cellSize };
			if (inRange(neighbour)) {
				points.push_back(neighbour);
			}
		}
	}

	return points;
}

void MinesweeperWindow::openTile(Point xy) {
	//spiller er over hvis der er en mine eller antall mulige ruter åpne er 0.
	
	
	
	if (at(xy).getMine())
	{
		gameOver();
		return;	
	}
	if(at(xy).getState()==Cell::closed){       

		at(xy).open();
		
		// til dette punktet åpner funksjonen der man trykker. 
		vector<Point>nabo=adjacentPoints(xy);
		int numMines=countMines(nabo);
		//  vector nabo , er nabo rutene til dr man har trykket. nuMines er antall Mines hos naboene. 
		
		if(!at(xy).getMine()){ // der man trykker er ikke bombe. 
			
			if(numMines>0){ //hvis det eksisterer bombe i ruten. 
				at(xy).setAdjMines(numMines);

			}
			// kaller tilbake til samme funskjson for nabo punktene som parameter.Rekursjon . 
			if(numMines==0){
				
				for(int k=0;k<nabo.size();++k)
				{
					openTile(nabo[k]);
				}
			}
			
		}
	}
	check();	
		
}

void MinesweeperWindow::check(){
	int antalltrygge=0;
	for(Tile*tile:tiles){
		if(tile->getState()==Cell::open){
			antalltrygge+=1;
		}
	}
	if(antalltrygge==antallRuter){
		gameWon();
	}
}
void MinesweeperWindow::flagTile(Point xy) {
	
	
	if(at(xy).getState()!=Cell::open)
	{
		at(xy).flag();
	}
}

void MinesweeperWindow::gameWon(){

	for(Tile*tile:tiles){
		if(tile->getMine()){
		tile->open();}
	}
	won.show();

}




//Kaller opentile ved venstreklikk og flagTile ved hoyreklikk/trykke med to fingre paa mac
void MinesweeperWindow::cb_click(Address, Address pw)
{
	Point xy{ Fl::event_x(),Fl::event_y() };
	MouseButton mb = static_cast<MouseButton>(Fl::event_button());
	auto& win = reference_to<MinesweeperWindow>(pw);

	if (!win.inRange(xy)) {
		return;
	}

	switch (mb) {
	case MouseButton::left:
		win.openTile(xy);
		break;
	case MouseButton::right:
		win.flagTile(xy);
		break;
	}

	win.flush();
}




/// spillet er over funksjon.
void MinesweeperWindow::gameOver(){
	gameover=true;
	for(Tile*tile:tiles){
		if(tile->getMine()){
		tile->open();}
	}
	over.show();
	
}








