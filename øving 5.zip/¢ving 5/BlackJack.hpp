#pragma once
#include "CardDeck.hpp"
#include"Card.hpp"




class BlackJack{
    private:
    CardDeck deck;
    vector<Card>p;
    vector<Card>d;
    vector<Suit>repP;
    vector<Suit>repD;


    public:
    BlackJack(vector<Card>player,
    vector<Card>dealer,CardDeck card);
    void Shuffle();
    void Deal();
    void DealOnlyPlayer();
    void Show();
    int  ValueP();
    int GetValueP(int i);
    int GetValueD(int k);
    int  ValueD();
    int ValueDall();
    void showall();
    void cal (int a, int b);
    void Play();
    void Duell();
    bool win(int a);

    
};