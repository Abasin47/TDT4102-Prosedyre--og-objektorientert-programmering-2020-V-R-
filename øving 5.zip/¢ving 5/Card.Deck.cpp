#include "Card.hpp"
#include "std_lib_facilities.h"
#include "CardDeck.hpp"

CardDeck::CardDeck(){
    for (int i=0;i<4;++i){
        for(int s=2;s<15;++s){
            Card kort(static_cast<Suit>(i),static_cast<Rank>(s));
            cards.push_back(kort);
        }
    }

}
void CardDeck::swapen(int a, int b){
    swap(cards[a],cards[b]);

    

}
void CardDeck::print(){
    for(int i=0;i<cards.size();++i){
        cout<<cards[i].toString()<<endl;
    }
}

void CardDeck::printShort(){
    for(int i=0;i<cards.size();++i){
        cout<<cards[i].toStringShort()<<endl;
    }
}

void CardDeck::shuffle(){
    srand(static_cast<unsigned int>(time(0)));
    for(int i=0;i<cards.size();++i){
        int a=1+rand()%cards.size()-1;
        int b=1+rand()&cards.size()-1;
        swapen(a,b);
    }
}

Card CardDeck::drawCard(){
    Card draw=cards[cards.size()-1];
    cards.erase(cards.begin()+cards.size()-1);
    return draw;


}
