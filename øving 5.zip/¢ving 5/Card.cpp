#include "Card.hpp"
#include "std_lib_facilities.h"

string suitToString(Suit e){
    map<Suit,string> type;
    type[Suit::clubs]="clubs" ;
    type[Suit::diamonds]="diamonds";
    type[Suit::spades]="spades";
    type[Suit::hearts]="hearts";

    return type[e];

}
string rankToString (Rank a){
    map<Rank,string> type;
    type[Rank::two]="two";
    type[Rank::three]="three";
    type[Rank::four]="four";
    type[Rank::five]="five";
    type[Rank::six]="six";
    type[Rank::seven]="seven";
    type[Rank::eight]="eight";
    type[Rank::nine]="nine";
    type[Rank::ten]="ten";
    type[Rank::jack]="jack";
    type[Rank::queen]="queen";
    type[Rank::king]="king";
    type[Rank::ace]="ace";

    return type[a];

}

Card::Card(Suit suit,Rank rank):s{suit},r{rank}{}


Suit Card::getSuit(){
    return s;
     }
Rank Card::getRank(){
       return r;
}
string Card::toString(){
        string alt=rankToString(r)+" of "+suitToString(s);
        return  alt;
}

string Card::toStringShort(){
    string one=suitToString(s);
    int verdi=(static_cast<int>(r));
    string two=to_string(verdi);
    char three=toupper(one[0]);
    return three+two;
}


