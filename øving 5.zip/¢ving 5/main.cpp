//
// This is example code from Chapter 2.2 "The classic first program" of
// "Programming -- Principles and Practice Using C++" by Bjarne Stroustrup
// 
// keep_window_open() added for TDT4102, excercise 0

// This program outputs the message "Hello, World!" to the monitor

#include "std_lib_facilities.h"
#include "Card.hpp"
#include "CardDeck.hpp"
#include "BlackJack.hpp"

//------------------------------------------------------------------------------'

// C++ programs start by executing the function main
int main()
{
	

	cout<<"oppgave 1a)"<<setw(5)<<suitToString(Suit::diamonds)<<endl;
	cout<<"oppgave 1b)"<<setw(5)<<rankToString(Rank::two)<<endl;
	cout<<"oppgave 1c:Fordi"<<endl;
	cout<<"oppgave 2,klasser"<<endl;
	Card c(Suit::diamonds,Rank::ace);
	//cout<<c.getSuit()<<setw(3)<<":color"<<endl;
	//cout<<c.getRank()<<setw(3)<<":number"<<endl;
	cout<<c.toString()<<endl;
	cout<<"short rep:"<<c.toStringShort()<<endl;
	cout<<"Oppgave 3 ::"<<endl;
	CardDeck j;
	//j.swapen(0,1);
	/*j.shuffle();
	j.print();
	cout<<"-------------------------------"<<endl;
	cout<<"print short"<<endl;
	j.printShort();
	cout<<":::::::::::::::"<<endl;
	cout<<j.drawCard()<<endl;
	cout<<":::::::::::::::::"<<endl;
	j.print();
	cout<<":::::::"<<endl;
	j.shuffle();
	j.print();
	*/
	vector<Card>player;
    vector<Card>dealer;
	CardDeck card;
	

	BlackJack b(player,dealer,card);
	b.Play();
	keep_window_open();
}

//------------------------------------------------------------------------------
