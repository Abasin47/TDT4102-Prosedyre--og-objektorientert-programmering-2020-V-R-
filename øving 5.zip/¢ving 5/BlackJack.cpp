#include "BlackJack.hpp"
#include "Card.hpp"
#include "CardDeck.hpp"
#include "std_lib_facilities.h"
#include "algorithm"

BlackJack::BlackJack(vector<Card>player,
    vector<Card>dealer,CardDeck card){
    player=p;
    dealer=d;  
    card=deck;   
}
void BlackJack::Shuffle(){
    deck.shuffle();
}
void BlackJack::Deal(){
     
   Card firstCard = deck.drawCard();
   Card secondCard = deck.drawCard();
   p.push_back(firstCard);
   d.push_back(secondCard);
}
void BlackJack::DealOnlyPlayer(){
    Card forP= deck.drawCard();
}
void BlackJack::Show(){
    cout<<"Your hand:"<<endl;
    for (int i=0;i<p.size();++i){
        cout<<endl;
       
        cout<<p[i].toString()<<endl;
        
    }

    cout<<endl;
    cout<<" "<<endl;
    cout<<"Dealer's hand:"<<endl;
    for (int i=1;i<d.size();++i){
        
        
        cout<<d[i].toString()<<endl;;
    }
    
    
}




int BlackJack::GetValueP(int i){
    Card given=p[i];
    int cardvalue=static_cast<int>(given.getRank());
    if(given.getRank()==Rank::jack||given.getRank()==Rank::queen||given.getRank()==Rank::king){
        int cardvalue=10;
        return cardvalue;}


    if (given.getRank()==Rank::ace){
        Suit element=given.getSuit();
        repD.push_back(element);
        vector<Suit>::iterator it = find(repD.begin(), repD.end(), element);
        if(it!=repD.end()){
            return cardvalue;
        }
        else
        {
            
        
        

        cout<<"Ace=11 or Ace=1:"<<endl;
        cardvalue=11;
        int choice;
        cin>>choice;
        if (choice==1){
        cardvalue=1;
        return cardvalue;
            }

        }
    }
    
    
    return cardvalue;

}


int BlackJack::GetValueD(int k){
    Card given=d[k];
    
    int cardvalue=static_cast<int>(given.getRank());
    if(given.getRank()==Rank::jack||given.getRank()==Rank::queen||given.getRank()==Rank::king){
        int cardvalue=10;
        return cardvalue;
    }
    
    
    if((given.getRank()==Rank::ace)){
        Suit element=given.getSuit();
        repP.push_back(element);
        vector<Suit>::iterator it = find(repP.begin(), repP.end(), element);
        if (it!=repP.end()){
            exit;}
        else{
            cout<<"Ace=11 or Ace=1:"<<endl;
            int cardvalue=11;
            int choice;
            cin>>choice;
            if (choice==1){                cardvalue=1;
                return cardvalue;
                }

            }
    }
        
    


    return cardvalue;

}

int BlackJack::ValueD(){
    int value=0;
    for(int k=1;k<d.size();++k){
        Card dealer=d[k];
        int valueFromCard=GetValueD(k);
        value+=valueFromCard;

    }
    return value;
}

int BlackJack::ValueP(){

    int value=0;
    for(int i=0;i<p.size();++i){
        Card c = p[i];
        int valueFromCard=GetValueP(i);
        value+=valueFromCard;
    }
    
    return value;
}

int BlackJack::ValueDall(){
    int value=0;
    for(int k=0;k<d.size();++k){
        Card dealer=d[k];
        int valueFromCard=GetValueD(k);
        value+=valueFromCard;

    }
    return value;
}
void BlackJack::showall(){
    cout<<"Your hand:"<<endl;
    for (int i=0;i<p.size();++i){
        cout<<endl;
       
        cout<<p[i].toString()<<endl;
        
    }

    cout<<endl;
    cout<<" "<<endl;
    cout<<"Dealer's hand:"<<endl;
    for (int i=0;i<d.size();++i){
        
        
        cout<<d[i].toString()<<endl;;
    }
    
    
}


void BlackJack::cal (int a, int b){
    if(abs((21-a))<abs((21-b))){
        cout<<"Lucky Bastard"<<endl;
    }
    else{
        cout<<"Uff , better luck next time"<<endl;

    }
}
void BlackJack::Duell(){
    cout<<"Reveal....."<<endl;
    showall();
    cout<<"Your points:"<<endl;
    cout<<ValueP()<<endl;
    cout<<"Dealer's points"<<endl;
    cout<<ValueDall()<<endl;
    cal(ValueP(),ValueDall());
    

}

bool BlackJack::win(int a){
    if(a==21){
        return true;
    }
    
 

}


void BlackJack::Play(){
    bool play;
    Shuffle();
    cout<<"1 to play , 0 to quit"<<endl;
    cin>>play;


    while(play){
        int diff;
        bool quit;
        Deal();
        Deal();
        Show();
        cout<<"Your points:"<<endl;
        cout<<ValueP()<<endl;
        cout<<"Dealer's points"<<endl;
        cout<<ValueD()<<endl;
    
        cout<<"Continue ?"<<endl;
        cin>>quit;
        while(quit){
             bool dealerrule;
             Shuffle();
             Deal();
             Show();
             cout<<"Your points:"<<endl;
             cout<<ValueP()<<endl;
             cout<<"Dealer's points"<<endl;
             cout<<ValueD()<<endl;
             if(ValueP()>21||ValueD()>21){
                 diff=ValueP()-ValueD();
                 if(diff>0){
                     cout<<"Lucky Bastard"<<endl;
                     break;}
                 if(diff<0){
                     cout<<"Uff , better luck next time"<<endl;
                     break;}
                }

             if (ValueD()==21 || ValueP()==21){
                if(21-ValueP()==0){
                     cout<<"Lucky Bastard"<<endl;
                     quit=false;
                     play=false;}
                if(21-ValueD()==0){
                     cout<<"Uff , better luck next time"<<endl;
                     quit=false;
                     play=false;

                }  

             }
             if(ValueD()>16&&ValueD()<21){
                 dealerrule=true;
                 Shuffle();
                 cout<<"Dealer stand."<<endl;
                 while (dealerrule){
                    DealOnlyPlayer();
                    Show();
                    cout<<"Your points:"<<endl;
                    cout<<ValueP()<<endl;
                    cout<<"Continue ?"<<endl;
                    cin>>quit;
                    if(quit=false){
                        DealOnlyPlayer();
                        Show();
                        cout<<"Your points:"<<endl;
                        cout<<ValueP()<<endl;
                        cout<<"Continue ?"<<endl;
                        cin>>quit;

                    }
                    if(quit=true){
                        DealOnlyPlayer();
                        Show();
                        cout<<"Your points:"<<endl;
                        cout<<ValueP()<<endl;
                        cout<<"Continue ?"<<endl;
                    if(ValueP()>=ValueD()&&ValueP()<21){
                        cout<<"Lucky Bastard"<<endl;
                        quit=false;
                        dealerrule=false;
                        play=false;
                        exit;}

                    }  
                    if(ValueP()>=ValueD()&&ValueP()>21){
                        cout<<"Uff , better luck next time"<<endl;
                        quit=false;
                        dealerrule=false;
                        play=false;
                        exit;}

                    }
                 
             }

            
        }
        Duell();
        play=false;
        exit;


    }


    
}



